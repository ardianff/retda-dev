@php
    $nilai = '';
    if ($tarif->bukan_nilai == 1) {
        $nilai = $tarif->nilai;
    } elseif ($tarif->up != 0) {
        $nilai = $tarif->nilai;
    } elseif ($tarif->nilai != 0) {
        $nilai = number_format($tarif->nilai, 0, ',', '.');
    }else {
        $nilai='';
    }
@endphp
<tr>
    <td><strong>{{ $tarif->number }}</strong></td>
    <td style="padding-left: 5px;">
        {{ $tarif->uraian }}
    </td>
    <td style="text-align: center;">{{ $tarif->satuan?->uraian ?? '' }}</td>
    @if ($tarif->jenis_id == 16)
    <td style="text-align:right">{{ $tarif->tarif_sarana != 0 ? number_format($tarif->tarif_sarana, 0, ',', '.') : '' }}</td>
    <td style="text-align:right">{{ $tarif->tarif_layanan != 0 ? number_format($tarif->tarif_layanan, 0, ',', '.') : '' }}</td>
    <td style="text-align:right">
        {{ $tarif->nilai !== null && $tarif->nilai != 0 ? number_format((float) $tarif->nilai, 0, ',', '.') : '' }}
    </td>        
    @else
    <td style="text-align:right">
        {{ $tarif->nilai !== null && $tarif->nilai != 0 ? number_format((float) $tarif->nilai, 0, ',', '.') : '' }}
    </td>
        
    @endif
    <td>{{ $tarif->keterangan}}</td>
</tr>

@if ($tarif->children->count() > 0)
    @foreach ($tarif->children as $child)
        @include('print.lampiran.partialpdf', ['tarif' => $child])
    @endforeach
@endif