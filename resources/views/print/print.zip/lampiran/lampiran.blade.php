@extends('template.master')

@section('breadcumb')
<li class="breadcrumb-item" style="float: left;"><a href="{{route('print.lampiran')}}"> Tarif</a> </li>

@endsection
@push('css')
    <style>
         .hidden {
      display: none;
    }
    
    </style>
@endpush

@section('content')
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header bg-dark">Filter Print Lampiran Tarif</div>
            <div class="card-body">
                <form action="{{route('print.lampiranExport')}}" method="get" target="_blank">
                    @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group row mb-1">
                                <label for="" class="col-md-2 ">Pilih Pergub</label>
                                <div class="col-md-6">
                                    <select id="ta_id" class="form-control " name="ta_id" required>
                                        @foreach ($ta as $item)
                                        
                                        <option   value="{{$item->id}}">Tahun {{$item->tahun}}||{{$item->deskripsi}}</option>
                                        @endforeach
                                        
                                        </select>
                                </div>
                            </div>
                            <div class="form-group row mb-1">
                                <label for="" class="col-md-2 ">Pilih OPD</label>
                                <div class="col-md-6">
                                    <select id="opd_id" class="form-control select2" name="opd_id" required>
                                        <option value=""></option>
                                        @foreach ($opd as $item)
                                            
                                        <option  value="{{$item->id}}"> {{$item->opd}}</option>
                                        @endforeach 
                                        
                                        </select>
                                </div>
                            </div>
                            <div class="form-group row mb-1">
                                <label for="" class="col-md-2 ">Pilih Balai/UPPD/UPT</label>
                                <div class="col-md-6">
                                    <select id="uppd_id" class="form-control " name="uppd_id" required>
                                        <option value=""></option>
                                        @foreach ($uppd as $item)
                                            
                                        <option  value="{{$item->id}}"> {{$item->nama}}</option>
                                        @endforeach 
                                        
                                        </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-md-2 ">Golongan Retribusi</label>
                                <div class="col-md-6">
                                    <select id="gol_id" class="form-control " name="gol_id" required>
                                        <option value=""></option>

                                        @foreach ($golongan as $item)                            
                                        <option  value="{{$item->id}}"> {{$item->name}}</option>
                                        @endforeach
                                        
                                        </select>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-md-4">
                                        <div class="btn-group">

                                            <button type="submit" name="action" value="pdf" class="btn btn-danger btn-sm mr-3" target="_blank">
                                                Preview PDF <i class="fas fa-file-pdf"></i>
                                            </button>
                    
                                            <button type="submit" name="action" value="excel" class="btn btn-success btn-sm" target="_blank">
                                                Download Excel <i class="fas fa-file-excel"></i>
                                            </button>
                                        </div>
                                        </div>
                                </div>
                         
                        </div>
                       
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
@push('scripts')
    <script>
 $(function () {
    
    $('#opd_id ').select2({
    placeholder: "Pilih OPD",
    allowClear: true
});
    $('#uppd_id ').select2({
    placeholder: "Pilih UPPD/Balai/UPT",
    allowClear: true
});

    $('#gol_id ').select2({
    placeholder: "Golongan Retribusi",
    allowClear: true
});

});

var userLevel = @json(auth()->user()->level); // Ambil user level dari PHP ke JavaScript
    var allowedLevels = [1, 2, 3, 6]; // Level yang diperbolehkan

    $('#opd_id').on('input', function() {
        let opd_id = $(this).val();
        $('#uppd_id').empty().append('<option value="">-- Pilih UPPD/Balai/Satker --</option>');

        if (opd_id) {
            $.ajax({
                url: `{{ url('/opd/uppd') }}/${opd_id}`,
                type: 'GET',
                success: function(data) {
                    // Cek apakah user level ada dalam daftar allowedLevels
                    if (allowedLevels.includes(userLevel)) {
                        $('#uppd_id').append(`<option value="0">Keseluruhan</option>`);
                    }

                    // Tambahkan data dari AJAX response
                    data.forEach(function(uppd) {
                        $('#uppd_id').append(`<option value="${uppd.id}">${uppd.nama}</option>`);
                    });
                },
                error: function() {
                    alert('Gagal mengambil data Balai.');
                }
            });
        }
    });
    </script>
@endpush